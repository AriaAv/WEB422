import { Position } from './position';

describe('Position', () => {
  it('should create an instance', () => {
    expect(new Position()).toBeTruthy();
  });
});
