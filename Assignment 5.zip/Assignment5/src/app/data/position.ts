export class Position {
    _id: string;
    PositionName: string;
    PositionDescription: string;
    PositonBaseSalary: number;
    __v: number; 
}
