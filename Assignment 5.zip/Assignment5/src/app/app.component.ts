/********************************************************************************* 
*  WEB422 – Assignment 05 
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part of this 
*  assignment has been copied manually or electronically from any other source (including web sites) or  
*  distributed to other students. 
* 
*  Name: Aria Avazkhani Student ID: 134465160 Date: Mar 22,2019
* 
********************************************************************************/ 


import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: []
})
export class AppComponent {
  title = 'Assignment5';
}
